
CREATE TABLE IF NOT EXISTS `fakultas` (
  `kd_fakultas` varchar(10) NOT NULL,
  `fakultas` varchar(50) NOT NULL,
  PRIMARY KEY  (`kd_fakultas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


